QAZI DAILY ACCOUNTS — INSTALLABLE WEB APP

This is a PWA package. It must be uploaded to an HTTPS website before Android Chrome can install it as an app.
Do not open index.html directly from the Downloads folder; service workers and PWA installation require HTTPS (or localhost).

After hosting:
1. Open the HTTPS website in Google Chrome on Android.
2. Tap Chrome's three-dot menu.
3. Tap "Install app" (or "Add to Home screen" if shown).
4. Confirm Install. The Qazi Accounts icon will appear on the home screen/app drawer.

Files:
- index.html: daily accounts app
- manifest.webmanifest: app name, icon and standalone display settings
- sw.js: offline app shell cache
- icons/: Android app icons

Daily records are stored in the browser's local storage on that device. Export CSV backups regularly.
